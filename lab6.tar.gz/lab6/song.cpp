#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>

#include "song.h"


using namespace std;


Song::Song() {
    title = new char[MAX_STR];
    artist = new char[MAX_STR];
    year = 0;
    duration = 0.00;

}

istream &operator>>(istream &isObject, Song &song) {
    cout << "title: ";
    isObject.ignore();
    isObject.getline(song.title, MAX_STR);

    cout << "artist: ";
    isObject.getline(song.artist, MAX_STR);
    cout << "year: ";
    isObject >> song.year;
    cout << "duration ";
    isObject >> song.duration;
    return isObject;
}

ostream &operator<<(ostream &osObject, const Song &song) {
    osObject << "Title: " << song.title << endl
             << "Artist: " << song.artist << endl
             << "Year: " << song.year << endl
             << "Duration: " << song.duration << endl;
    return osObject;
}

const Song &Song::operator=(const Song& rightHandSong) {
    if (this != &rightHandSong) {
        this->title = rightHandSong.title;
        this->artist = rightHandSong.artist;
        this->year = rightHandSong.year;
        this->duration = rightHandSong.duration;
    }
    return *this;
}

int Song::getYear() {
    return year;
}

void Song::setYear(int y) {
    year = y;

}


double Song::getDuration() {
    return duration;
}

void Song::setDuration(double d) {
    duration = d;
}


const char *Song::getTitle() {
    return title;
}

const char *Song::getArtist() {
    return artist;
}

void Song::setTitle(char t[]) {
    if (title != nullptr) {
        delete title;
    }
    title = new char[strlen(t) + 1];
    strcpy(title, t);
}

void Song::setArtist(char a[]) {
    if (artist != nullptr) {
        delete artist;
    }
    artist = new char[strlen(a) + 1];
    strcpy(artist, a);
}

Song::~Song() {

}




