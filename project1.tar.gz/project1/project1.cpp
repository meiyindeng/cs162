#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;
int main()
{
    int rand1;
    int rand2;
    int rand3;
    int betAmount=0;
    int initialBalance = 100;
    string name;

    srand((unsigned) time(0));
    rand1 = (rand() % 6) + 1;
    rand2 = (rand() % 6) + 1;
    rand3 = (rand() % 6) + 1;

    bool playAgain = false;


    cout << "What is your name?\n";
    cin >> name;

    do{

    bool  validBetAmount = false;
    while (!validBetAmount) {
	cout << "Well, "<<  name << " please enter a bet amount (between 0 and " << initialBalance <<"): \n";
	cin >> betAmount;
	if (betAmount >= 0 && betAmount <= initialBalance) {
           validBetAmount = true;
        } else {
        validBetAmount = false; cout << "Invalid bet.";
        }
    }

    bool validFirstNumber=false;
    int firstNumber=0;
    while (!validFirstNumber) {
        cout << "now, enter the first number (between 1 and 6):";
        cin >> firstNumber;
        if (firstNumber >=1 && firstNumber<=6) {
        validFirstNumber=true;
        }else{
        validFirstNumber=false; cout <<"Invalid number.";
        }
    }



    bool validSecondNumber=false;
    int secondNumber=0;
    while (!validSecondNumber) {
        cout << "now, enter the second number (between 1 and 6):";
        cin >> secondNumber;
        if (secondNumber >=1 && secondNumber<=6) {
        validSecondNumber=true;
        }else{
        validSecondNumber=false; cout << "Invalid number.";
        }
    }


   bool validThirdNumber=false;
   int thirdNumber=0;
   while (!validThirdNumber) {
        cout << "now, enter the third number (between 1 and 6):";
        cin >> thirdNumber;
        if (thirdNumber >=1 && thirdNumber <=6) {
        validThirdNumber=true;
        }else{
        validThirdNumber=false; cout << "Invalid number.";
        }
   }

	cout << "the lottery numbers are: " << rand1 << " "<< rand2 << " "<< rand3 << endl;

	int winMultiplier = 0;
	int winAmount = 0;
	if (rand1==firstNumber) { winMultiplier = winMultiplier +1;}
	if (rand2==secondNumber) { winMultiplier = winMultiplier +1;}
	if (rand3==thirdNumber) { winMultiplier = winMultiplier +1;}
	winAmount = betAmount * winMultiplier;

    initialBalance = initialBalance - betAmount + winAmount;

    if (winMultiplier > 0) {
            cout << name << ", you guessed "<< winMultiplier << " number(s)! :­)\n" << "you get " << winAmount << " added to your pot.\n";
    }

    if (winMultiplier <= 0) {
            cout << name << ", you didn't guess any numbers :­(\n" <<"you lose " << betAmount << " coins\n";
    }

    if (initialBalance <=0) {
        cout << "You have no money left!";
        cout << "GOODBYE!";
        return 0;
    }

    bool correctInput = false;
    string playAgainInput;
    while (!correctInput){
            cout << name << ", do you want to play again? (y or n)";
            cin >> playAgainInput;
            if (playAgainInput == "y" || playAgainInput == "Y" || playAgainInput == "n" || playAgainInput == "N") {
            correctInput = true;
            }

    }

    if (playAgainInput== "y"|| playAgainInput =="Y") {
            playAgain = true;
            } else {
            playAgain = false;
            }



    }

    while (playAgain);





    cout << name << " Your pot is: " << initialBalance << " coins\n";
    cout << "GOODBYE!";


    return 0;

}
